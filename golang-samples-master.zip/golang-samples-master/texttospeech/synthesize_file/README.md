# Synthesize File
See [Creating Voice Audio Files](https://cloud.google.com/text-to-speech/docs/create-audio).
