## Google Cloud Storage on App Engine standard

See the [documentation][doc] for a full tutorial.

[doc]: https://cloud.google.com/appengine/docs/standard/go/googlecloudstorageclient/app-engine-cloud-storage-sample
