# Cloud Natural Language API Go samples

This directory contains [Cloud Natural Language API](https://cloud.google.com/natural-language/) Go samples.

## Samples

### analyze

This is a simple command line tool that shows off the API's features.

[Go Code](analyze)
